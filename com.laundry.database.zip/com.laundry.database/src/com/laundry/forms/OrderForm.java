package com.laundry.forms;

import com.laundry.database.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Date;

public class OrderForm extends JFrame {
    private JComboBox<String> customerComboBox, serviceComboBox;
    private JTextField weightField, notesField;
    private JTable orderTable;
    private DefaultTableModel tableModel;
    
    public OrderForm() {
        initComponents();
        loadCustomers();
        loadServices();
        loadOrders();
    }
    
    private void initComponents() {
        setTitle("Pesanan Laundry");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Pesanan"));
        
        formPanel.add(new JLabel("Pelanggan:"));
        customerComboBox = new JComboBox<>();
        formPanel.add(customerComboBox);
        
        formPanel.add(new JLabel("Layanan:"));
        serviceComboBox = new JComboBox<>();
        formPanel.add(serviceComboBox);
        
        formPanel.add(new JLabel("Berat (kg):"));
        weightField = new JTextField();
        formPanel.add(weightField);
        
        formPanel.add(new JLabel("Catatan:"));
        notesField = new JTextField();
        formPanel.add(notesField);
        
        JButton saveButton = new JButton("Simpan Pesanan");
        saveButton.addActionListener(e -> saveOrder());
        formPanel.add(saveButton);
        
        JButton deleteButton = new JButton("Hapus");
        deleteButton.addActionListener(e -> deleteOrder());
        formPanel.add(deleteButton);
        
        // Table Panel
        String[] columns = {"ID", "Pelanggan", "Layanan", "Berat", "Total", "Status", "Tanggal"};
        tableModel = new DefaultTableModel(columns, 0);
        orderTable = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(orderTable);
        
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
    
    private void loadCustomers() {
        customerComboBox.removeAllItems();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT id, name FROM customers";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                customerComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void loadServices() {
        serviceComboBox.removeAllItems();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT id, name, price FROM services";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                serviceComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name") + " (Rp " + rs.getDouble("price") + "/kg)");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void saveOrder() {
        if (customerComboBox.getSelectedItem() == null || serviceComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Pilih pelanggan dan layanan!");
            return;
        }
        
        String weightStr = weightField.getText();
        String notes = notesField.getText();
        
        if (weightStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan berat laundry!");
            return;
        }
        
        try {
            double weight = Double.parseDouble(weightStr);
            
            // Get customer ID
            String customerStr = (String) customerComboBox.getSelectedItem();
            int customerId = Integer.parseInt(customerStr.split(" - ")[0]);
            
            // Get service ID and price
            String serviceStr = (String) serviceComboBox.getSelectedItem();
            int serviceId = Integer.parseInt(serviceStr.split(" - ")[0]);
            
            // Get service price
            double servicePrice = 0;
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "SELECT price FROM services WHERE id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, serviceId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    servicePrice = rs.getDouble("price");
                }
            }
            
            double total = weight * servicePrice;
            
            // Save order
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO orders (customer_id, service_id, weight, total, status, notes, order_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, customerId);
                stmt.setInt(2, serviceId);
                stmt.setDouble(3, weight);
                stmt.setDouble(4, total);
                stmt.setString(5, "Diterima");
                stmt.setString(6, notes);
                stmt.setDate(7, new java.sql.Date(new Date().getTime()));
                
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Pesanan berhasil disimpan!\nTotal: Rp " + total);
                clearForm();
                loadOrders();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Berat harus berupa angka!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menyimpan pesanan!");
        }
    }
    
    private void deleteOrder() {
        int row = orderTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih pesanan yang akan dihapus!");
            return;
        }
        
        int id = (int) tableModel.getValueAt(row, 0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM orders WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Pesanan berhasil dihapus!");
            loadOrders();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menghapus pesanan!");
        }
    }
    
    private void loadOrders() {
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT o.id, c.name as customer_name, s.name as service_name, " +
                        "o.weight, o.total, o.status, o.order_date " +
                        "FROM orders o " +
                        "JOIN customers c ON o.customer_id = c.id " +
                        "JOIN services s ON o.service_id = s.id " +
                        "ORDER BY o.order_date DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("customer_name"),
                    rs.getString("service_name"),
                    rs.getDouble("weight") + " kg",
                    "Rp " + rs.getDouble("total"),
                    rs.getString("status"),
                    rs.getDate("order_date")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void clearForm() {
        weightField.setText("");
        notesField.setText("");
    }
}