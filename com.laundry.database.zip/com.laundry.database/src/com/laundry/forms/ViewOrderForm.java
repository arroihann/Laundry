package com.laundry.forms;

import com.laundry.database.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewOrderForm extends JFrame {
    private JTable orderTable;
    private DefaultTableModel tableModel;
    
    public ViewOrderForm() {
        initComponents();
        loadOrders();
    }
    
    private void initComponents() {
        setTitle("Status Pesanan");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Status Pesanan Laundry");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titlePanel.add(titleLabel);
        
        // Table Panel
        String[] columns = {"ID Pesanan", "Pelanggan", "Layanan", "Berat", "Total", "Status", "Tanggal"};
        tableModel = new DefaultTableModel(columns, 0);
        orderTable = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(orderTable);
        
        // Refresh Button
        JPanel buttonPanel = new JPanel();
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadOrders());
        buttonPanel.add(refreshButton);
        
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
    
    private void loadOrders() {
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT o.id, c.name as customer_name, s.name as service_name, " +
                        "o.weight, o.total, o.status, o.order_date " +
                        "FROM orders o " +
                        "JOIN customers c ON o.customer_id = c.id " +
                        "JOIN services s ON o.service_id = s.id " +
                        "ORDER BY o.order_date DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("customer_name"),
                    rs.getString("service_name"),
                    rs.getDouble("weight") + " kg",
                    "Rp " + rs.getDouble("total"),
                    rs.getString("status"),
                    rs.getDate("order_date")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}