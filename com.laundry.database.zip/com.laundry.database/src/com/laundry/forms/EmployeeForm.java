package com.laundry.forms;

import com.laundry.database.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EmployeeForm extends JFrame {
    private JTextField nameField, positionField, phoneField;
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    
    public EmployeeForm() {
        initComponents();
        loadEmployees();
    }
    
    private void initComponents() {
        setTitle("Data Karyawan");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Karyawan"));
        
        formPanel.add(new JLabel("Nama:"));
        nameField = new JTextField();
        formPanel.add(nameField);
        
        formPanel.add(new JLabel("Posisi:"));
        positionField = new JTextField();
        formPanel.add(positionField);
        
        formPanel.add(new JLabel("Telepon:"));
        phoneField = new JTextField();
        formPanel.add(phoneField);
        
        JButton saveButton = new JButton("Simpan");
        saveButton.addActionListener(e -> saveEmployee());
        formPanel.add(saveButton);
        
        JButton deleteButton = new JButton("Hapus");
        deleteButton.addActionListener(e -> deleteEmployee());
        formPanel.add(deleteButton);
        
        // Table Panel
        String[] columns = {"ID", "Nama", "Posisi", "Telepon"};
        tableModel = new DefaultTableModel(columns, 0);
        employeeTable = new JTable(tableModel);
        employeeTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = employeeTable.getSelectedRow();
                if (row >= 0) {
                    nameField.setText(tableModel.getValueAt(row, 1).toString());
                    positionField.setText(tableModel.getValueAt(row, 2).toString());
                    phoneField.setText(tableModel.getValueAt(row, 3).toString());
                }
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
    
    private void saveEmployee() {
        String name = nameField.getText();
        String position = positionField.getText();
        String phone = phoneField.getText();
        
        if (name.isEmpty() || position.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
            return;
        }
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO employees (name, position, phone) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, position);
            stmt.setString(3, phone);
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            clearForm();
            loadEmployees();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menyimpan data!");
        }
    }
    
    private void deleteEmployee() {
        int row = employeeTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!");
            return;
        }
        
        int id = (int) tableModel.getValueAt(row, 0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM employees WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
            clearForm();
            loadEmployees();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menghapus data!");
        }
    }
    
    private void loadEmployees() {
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM employees";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("position"),
                    rs.getString("phone")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void clearForm() {
        nameField.setText("");
        positionField.setText("");
        phoneField.setText("");
    }
}