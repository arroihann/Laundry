package com.laundry.forms;

import com.laundry.database.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ServiceForm extends JFrame {
    private JTextField nameField, priceField, descriptionField;
    private JTable serviceTable;
    private DefaultTableModel tableModel;
    
    public ServiceForm() {
        initComponents();
        loadServices();
    }
    
    private void initComponents() {
        setTitle("Data Layanan");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Layanan"));
        
        formPanel.add(new JLabel("Nama Layanan:"));
        nameField = new JTextField();
        formPanel.add(nameField);
        
        formPanel.add(new JLabel("Harga (per kg):"));
        priceField = new JTextField();
        formPanel.add(priceField);
        
        formPanel.add(new JLabel("Deskripsi:"));
        descriptionField = new JTextField();
        formPanel.add(descriptionField);
        
        JButton saveButton = new JButton("Simpan");
        saveButton.addActionListener(e -> saveService());
        formPanel.add(saveButton);
        
        JButton deleteButton = new JButton("Hapus");
        deleteButton.addActionListener(e -> deleteService());
        formPanel.add(deleteButton);
        
        // Table Panel
        String[] columns = {"ID", "Nama Layanan", "Harga", "Deskripsi"};
        tableModel = new DefaultTableModel(columns, 0);
        serviceTable = new JTable(tableModel);
        serviceTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = serviceTable.getSelectedRow();
                if (row >= 0) {
                    nameField.setText(tableModel.getValueAt(row, 1).toString());
                    priceField.setText(tableModel.getValueAt(row, 2).toString());
                    descriptionField.setText(tableModel.getValueAt(row, 3).toString());
                }
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(serviceTable);
        
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
    
    private void saveService() {
        String name = nameField.getText();
        String priceStr = priceField.getText();
        String description = descriptionField.getText();
        
        if (name.isEmpty() || priceStr.isEmpty() || description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
            return;
        }
        
        try {
            double price = Double.parseDouble(priceStr);
            
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO services (name, price, description) VALUES (?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setDouble(2, price);
                stmt.setString(3, description);
                
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                clearForm();
                loadServices();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Harga harus berupa angka!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menyimpan data!");
        }
    }
    
    private void deleteService() {
        int row = serviceTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!");
            return;
        }
        
        int id = (int) tableModel.getValueAt(row, 0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM services WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
            clearForm();
            loadServices();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menghapus data!");
        }
    }
    
    private void loadServices() {
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM services";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getString("description")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void clearForm() {
        nameField.setText("");
        priceField.setText("");
        descriptionField.setText("");
    }
}