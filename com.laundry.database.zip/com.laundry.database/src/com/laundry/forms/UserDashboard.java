package com.laundry.forms;

import javax.swing.*;
import java.awt.*;

public class UserDashboard extends JFrame {
    
    public UserDashboard() {
        initComponents();
    }
    
    private void initComponents() {
        setTitle("User Dashboard - Manajemen Laundry");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        
        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        
        // Transaction Menu
        JMenu transactionMenu = new JMenu("Transaksi");
        JMenuItem orderItem = new JMenuItem("Buat Pesanan");
        JMenuItem viewOrderItem = new JMenuItem("Lihat Pesanan");
        
        orderItem.addActionListener(e -> new OrderForm().setVisible(true));
        viewOrderItem.addActionListener(e -> new ViewOrderForm().setVisible(true));
        
        transactionMenu.add(orderItem);
        transactionMenu.add(viewOrderItem);
        
        // Logout Menu
        JMenu logoutMenu = new JMenu("Logout");
        JMenuItem logoutItem = new JMenuItem("Keluar");
        logoutItem.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });
        logoutMenu.add(logoutItem);
        
        menuBar.add(transactionMenu);
        menuBar.add(logoutMenu);
        
        setJMenuBar(menuBar);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Welcome Panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(Color.CYAN);
        JLabel welcomeLabel = new JLabel("Selamat Datang di Dashboard User");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomePanel.add(welcomeLabel);
        
        // Info Panel
        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Menu Utama"));
        
        JButton orderButton = new JButton("Buat Pesanan Baru");
        JButton viewButton = new JButton("Lihat Status Pesanan");
        
        orderButton.addActionListener(e -> new OrderForm().setVisible(true));
        viewButton.addActionListener(e -> new ViewOrderForm().setVisible(true));
        
        infoPanel.add(orderButton);
        infoPanel.add(viewButton);
        
        mainPanel.add(welcomePanel, BorderLayout.NORTH);
        mainPanel.add(infoPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
}