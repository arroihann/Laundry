package com.laundry.forms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboard extends JFrame {
    
    public AdminDashboard() {
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Admin Dashboard - Manajemen Laundry");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        
        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        
        // Master Data Menu
        JMenu masterMenu = new JMenu("Master Data");
        JMenuItem customerItem = new JMenuItem("Data Pelanggan");
        JMenuItem serviceItem = new JMenuItem("Data Layanan");
        JMenuItem employeeItem = new JMenuItem("Data Karyawan");
        
        customerItem.addActionListener(e -> new CustomerForm().setVisible(true));
        serviceItem.addActionListener(e -> new ServiceForm().setVisible(true));
        employeeItem.addActionListener(e -> new EmployeeForm().setVisible(true));
        
        masterMenu.add(customerItem);
        masterMenu.add(serviceItem);
        masterMenu.add(employeeItem);
        
        // Transaction Menu
        JMenu transactionMenu = new JMenu("Transaksi");
        JMenuItem orderItem = new JMenuItem("Pesanan");
        JMenuItem paymentItem = new JMenuItem("Pembayaran");
        
        orderItem.addActionListener(e -> new OrderForm().setVisible(true));
        paymentItem.addActionListener(e -> new PaymentForm().setVisible(true));
        
        transactionMenu.add(orderItem);
        transactionMenu.add(paymentItem);
        
        // Report Menu
        JMenu reportMenu = new JMenu("Laporan");
        JMenuItem reportItem = new JMenuItem("Laporan Transaksi");
        reportMenu.add(reportItem);
        
        // Logout Menu
        JMenu logoutMenu = new JMenu("Logout");
        JMenuItem logoutItem = new JMenuItem("Keluar");
        logoutItem.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });
        logoutMenu.add(logoutItem);
        
        menuBar.add(masterMenu);
        menuBar.add(transactionMenu);
        menuBar.add(reportMenu);
        menuBar.add(logoutMenu);
        
        setJMenuBar(menuBar);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Welcome Panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(Color.LIGHT_GRAY);
        JLabel welcomeLabel = new JLabel("Selamat Datang di Dashboard Admin");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel);
        
        // Info Panel
        JPanel infoPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Informasi Sistem"));
        
        infoPanel.add(new JLabel("Total Pelanggan: 0"));
        infoPanel.add(new JLabel("Total Pesanan: 0"));
        infoPanel.add(new JLabel("Pesanan Hari Ini: 0"));
        infoPanel.add(new JLabel("Pendapatan Bulan Ini: Rp 0"));
        
        mainPanel.add(welcomePanel, BorderLayout.NORTH);
        mainPanel.add(infoPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
}
