package com.laundry.forms;

import com.laundry.database.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Date;

public class PaymentForm extends JFrame {
    private JComboBox<String> orderComboBox;
    private JTextField amountField;
    private JComboBox<String> methodComboBox;
    private JTable paymentTable;
    private DefaultTableModel tableModel;
    
    public PaymentForm() {
        initComponents();
        loadUnpaidOrders();
        loadPayments();
    }
    
    private void initComponents() {
        setTitle("Pembayaran");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Form Pembayaran"));
        
        formPanel.add(new JLabel("Pesanan:"));
        orderComboBox = new JComboBox<>();
        formPanel.add(orderComboBox);
        
        formPanel.add(new JLabel("Jumlah Bayar:"));
        amountField = new JTextField();
        formPanel.add(amountField);
        
        formPanel.add(new JLabel("Metode Bayar:"));
        methodComboBox = new JComboBox<>(new String[]{"Cash", "Transfer", "Kartu Kredit"});
        formPanel.add(methodComboBox);
        
        JButton payButton = new JButton("Bayar");
        payButton.addActionListener(e -> processPayment());
        formPanel.add(payButton);
        
        JButton deleteButton = new JButton("Hapus");
        deleteButton.addActionListener(e -> deletePayment());
        formPanel.add(deleteButton);
        
        // Table Panel
        String[] columns = {"ID", "Pesanan", "Pelanggan", "Jumlah", "Metode", "Tanggal"};
        tableModel = new DefaultTableModel(columns, 0);
        paymentTable = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(paymentTable);
        
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel);
        setLocationRelativeTo(null);
    }
    
    private void loadUnpaidOrders() {
        orderComboBox.removeAllItems();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT o.id, c.name, o.total FROM orders o " +
                        "JOIN customers c ON o.customer_id = c.id " +
                        "WHERE o.status != 'Lunas' " +
                        "ORDER BY o.order_date DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                orderComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name") + " (Rp " + rs.getDouble("total") + ")");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void processPayment() {
        if (orderComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Pilih pesanan!");
            return;
        }
        
        String amountStr = amountField.getText();
        if (amountStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan jumlah bayar!");
            return;
        }
        
        try {
            double amount = Double.parseDouble(amountStr);
            
            // Get order ID
            String orderStr = (String) orderComboBox.getSelectedItem();
            int orderId = Integer.parseInt(orderStr.split(" - ")[0]);
            String method = (String) methodComboBox.getSelectedItem();
            
            // Save payment
            try (Connection conn = DatabaseConnection.getConnection()) {
                // Insert payment
                String sql = "INSERT INTO payments (order_id, amount, payment_method, payment_date) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, orderId);
                stmt.setDouble(2, amount);
                stmt.setString(3, method);
                stmt.setDate(4, new java.sql.Date(new Date().getTime()));
                
                stmt.executeUpdate();
                
                // Update order status
                String updateSql = "UPDATE orders SET status = 'Lunas' WHERE id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setInt(1, orderId);
                updateStmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Pembayaran berhasil diproses!");
                clearForm();
                loadUnpaidOrders();
                loadPayments();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah bayar harus berupa angka!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error memproses pembayaran!");
        }
    }
    
    private void deletePayment() {
        int row = paymentTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Pilih pembayaran yang akan dihapus!");
            return;
        }
        
        int id = (int) tableModel.getValueAt(row, 0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM payments WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Pembayaran berhasil dihapus!");
            loadPayments();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error menghapus pembayaran!");
        }
    }
    
    private void loadPayments() {
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT p.id, p.order_id, c.name as customer_name, " +
                        "p.amount, p.payment_method, p.payment_date " +
                        "FROM payments p " +
                        "JOIN orders o ON p.order_id = o.id " +
                        "JOIN customers c ON o.customer_id = c.id " +
                        "ORDER BY p.payment_date DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    "Order #" + rs.getInt("order_id"),
                    rs.getString("customer_name"),
                    "Rp " + rs.getDouble("amount"),
                    rs.getString("payment_method"),
                    rs.getDate("payment_date")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void clearForm() {
        amountField.setText("");
    }
}
